package com.TimeVenture.task.model.enums;

public enum Action {
    INSERT,
    UPDATE,
    DELETE
}
