package com.TimeVenture.model.enums;

public enum Auth {
    MANAGER,
    MEMBER
}
