package com.TimeVenture.task.model.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH;

}

