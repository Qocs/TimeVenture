package com.TimeVenture.model.enums;

public enum Role {
    USER,
    ADMIN
}
