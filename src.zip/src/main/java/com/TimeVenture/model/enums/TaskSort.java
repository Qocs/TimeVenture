package com.TimeVenture.task.model.enums;

public enum TaskSort {
    DUE_DATE_ASC,
    DUE_DATE_DESC,
    MEMBER_ASC,
    MEMBER_DESC,
    CREATED_DATE_ASC,
    CREATED_DATE_DESC,
    PRIORITY_ASC,
    PRIORITY_DESC
}
