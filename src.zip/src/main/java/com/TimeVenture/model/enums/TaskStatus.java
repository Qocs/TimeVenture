package com.TimeVenture.task.model.enums;

public enum TaskStatus {
    TODO,
    DOING,
    DONE,
    HOLD
}
