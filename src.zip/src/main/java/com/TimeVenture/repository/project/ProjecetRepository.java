package com.TimeVenture.repository.project;

import com.TimeVenture.model.entity.project.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjecetRepository extends JpaRepository<Project, Long> {

}
